// Base URL for Spring Boot backend
const BASE_URL = "http://localhost:8080/api";

// Utility to get stored role (ADMIN / MEMBER)
function getRole() {
    return localStorage.getItem("userRole") || "MEMBER";
}

// ------------------ MEMBER FUNCTIONS ------------------

function addMember() {
    fetch(`${BASE_URL}/members`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            name: mName.value,
            email: mEmail.value,
            phone: mPhone.value,
            membershipType: mType.value
        })
    })
        .then(res => res.json())
        .then(data => alert(`✔ Member added with ID: ${data.id}`))
        .catch(() => alert("❌ Error adding member"));
}

function updateMember() {
    const id = updateId.value;

    fetch(`${BASE_URL}/members/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            name: updateName.value,
            email: updateEmail.value,
            phone: updatePhone.value,
            membershipType: updateType.value
        })
    })
        .then(res => res.json())
        .then(data => alert(`✔ Member updated: ${data.id}`))
        .catch(() => alert("❌ Error updating member"));
}

function deleteMember() {
    const id = deleteId.value;

    fetch(`${BASE_URL}/members/${id}`, {
        method: "DELETE",
        headers: {
            "role": getRole()  // IMPORTANT ADMIN HEADER
        }
    })
        .then(res => res.text())
        .then(msg => alert(msg))
        .catch(() => alert("❌ Error deleting member"));
}


// ------------------ TRAINER FUNCTIONS ------------------

function addTrainer() {
    fetch(`${BASE_URL}/trainers`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            name: tName.value,
            email: tEmail.value,
            phone: tPhone.value,
            specialization: tSpec.value,
            experienceYears: tExp.value
        })
    })
        .then(res => res.json())
        .then(data => alert(`✔ Trainer added with ID: ${data.id}`))
        .catch(() => alert("❌ Error adding trainer"));
}



// ------------------ SESSION FUNCTIONS (FULL CRUD) ------------------

// CREATE
function bookSession() {
    fetch(`${BASE_URL}/sessions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            memberId: memberId.value,
            trainerId: trainerId.value,
            sessionType: sessionType.value
        })
    })
        .then(res => res.json())
        .then(data => alert(`✔ Session booked with ID: ${data.id}`))
        .catch(() => alert("❌ Error booking session"));
}

// READ ALL
function loadSessions() {
    fetch(`${BASE_URL}/sessions`)
        .then(res => res.json())
        .then(data => {
            sessions.textContent = JSON.stringify(data, null, 2);
        })
        .catch(() => alert("❌ Error loading sessions"));
}

// READ BY ID
function getSessionById() {
    const id = sessionId.value;

    fetch(`${BASE_URL}/sessions/${id}`)
        .then(res => res.json())
        .then(data => alert(JSON.stringify(data, null, 2)))
        .catch(() => alert("❌ Error fetching session"));
}

// UPDATE
function updateSession() {
    const id = updateSessionId.value;

    fetch(`${BASE_URL}/sessions/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            memberId: updateMemberId.value,
            trainerId: updateTrainerId.value,
            sessionType: updateSessionType.value
        })
    })
        .then(res => res.json())
        .then(data => alert(`✔ Session updated: ${data.id}`))
        .catch(() => alert("❌ Error updating session"));
}

// DELETE
function deleteSession() {
    const id = deleteSessionId.value;

    fetch(`${BASE_URL}/sessions/${id}`, {
        method: "DELETE",
        headers: {
            "role": getRole()  // ADMIN PROTECTED
        }
    })
        .then(res => res.text())
        .then(msg => alert(msg))
        .catch(() => alert("❌ Error deleting session"));
}

