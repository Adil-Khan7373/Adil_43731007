// Hardcoded demo users
const users = [
    {
        id: 1,
        name: "Adil Khan",
        email: "adil@example.com",
        password: "adil123",
        membershipType: "Premium"
    },
    {
        id: 2,
        name: "John Doe",
        email: "john@example.com",
        password: "john123",
        membershipType: "Basic"
    },
    {
        id: 3,
        name: "Priya Sharma",
        email: "priya@example.com",
        password: "priya123",
        membershipType: "Gold"
    }
];

/**
 * Validates login using local hardcoded users
 */
function loginUser() {

    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();

    if (!email || !password) {
        alert("Please enter both fields.");
        return;
    }

    const user = users.find(
        u => u.email === email && u.password === password
    );

    if (!user) {
        alert("Invalid email or password!");
        return;
    }

    // Save session data
    localStorage.setItem("userId", user.id);
    localStorage.setItem("userName", user.name);
    localStorage.setItem("userEmail", user.email);
    localStorage.setItem("userMembership", user.membershipType);

    // redirect to user
    window.location.href = "../users/user.html";
}
