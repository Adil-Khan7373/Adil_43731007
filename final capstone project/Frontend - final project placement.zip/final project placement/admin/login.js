const BASE_URL = "http://localhost:8080/api";

/**
 * Handles login for both ADMIN and USER
 */
function loginUser() {

    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();

    if (!email || !password) {
        alert("Please enter both email and password.");
        return;
    }

    fetch(`${BASE_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            email: email,
            password: password
        })
    })
        .then(res => {
            if (!res.ok) throw new Error("Invalid credentials");
            return res.json();
        })
        .then(user => {

            console.log("Login successful:", user);

            // Save session data
            localStorage.setItem("userRole", user.role);
            localStorage.setItem("userId", user.id);
            localStorage.setItem("userName", user.name);

            if (user.role === "ADMIN") {
                window.location.href = "../admin/admin.html";
            } else if (user.role === "MEMBER") {
                window.location.href = "../members/members.html"; // personal user dashboard
            } else {
                alert("Unknown role — contact administrator.");
            }

        })
        .catch(err => {
            console.error(err);
            alert("Invalid email or password");
        });
}
