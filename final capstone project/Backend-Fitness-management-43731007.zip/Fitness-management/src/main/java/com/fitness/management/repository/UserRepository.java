package com.fitness.management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.fitness.management.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}
