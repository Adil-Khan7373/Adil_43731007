package com.fitness.management.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.fitness.management.entity.Session;
import com.fitness.management.repository.SessionRepository;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/sessions")
public class SessionController {

    @Autowired
    private SessionRepository sessionRepository;

    // CREATE
    @PostMapping
    public Session bookSession(@RequestBody Session session) {
        session.setSessionTime(LocalDateTime.now());
        session.setStatus("BOOKED");
        return sessionRepository.save(session);
    }

    // READ ALL
    @GetMapping
    public List<Session> getAllSessions() {
        return sessionRepository.findAll();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Session getSessionById(@PathVariable Long id) {
        return sessionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Session not found"));
    }

    // UPDATE
    @PutMapping("/{id}")
    public Session updateSession(@PathVariable Long id, @RequestBody Session updatedSession) {

        Session session = sessionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Session not found"));

        session.setMemberId(updatedSession.getMemberId());
        session.setTrainerId(updatedSession.getTrainerId());
        session.setSessionType(updatedSession.getSessionType());
        session.setStatus(updatedSession.getStatus());
        session.setSessionTime(LocalDateTime.now());

        return sessionRepository.save(session);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteSession(@PathVariable Long id) {
        sessionRepository.deleteById(id);
        return "Session deleted with ID: " + id;
    }
}
