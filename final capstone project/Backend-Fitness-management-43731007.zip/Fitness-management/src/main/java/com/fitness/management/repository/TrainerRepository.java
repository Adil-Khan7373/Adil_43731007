package com.fitness.management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.fitness.management.entity.Trainer;
import java.util.List;

@Repository
public interface TrainerRepository extends JpaRepository<Trainer, Long> {

    // Find trainers by specialization
    List<Trainer> findBySpecialization(String specialization);

    // Find trainer by email
    Trainer findByEmail(String email);

    // Count trainers by experience years
    long countByExperienceYears(int years);
}
