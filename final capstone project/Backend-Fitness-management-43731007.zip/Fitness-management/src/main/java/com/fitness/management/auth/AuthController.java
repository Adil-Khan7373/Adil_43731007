package com.fitness.management.auth;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @PostMapping("/login")
    public Object login(@RequestBody LoginRequest request) {

        // Admin login hardcoded
        if (request.getEmail().equals("admin@fitness.com") &&
            request.getPassword().equals("admin123")) {
            return new UserResponse(1L, "Admin", "ADMIN");
        }

        // Member login hardcoded example
        if (request.getEmail().equals("user@fitness.com") &&
            request.getPassword().equals("user123")) {
            return new UserResponse(2L, "User", "MEMBER");
        }

        throw new RuntimeException("Invalid email or password");
    }
}
