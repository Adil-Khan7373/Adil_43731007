package com.fitness.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.fitness.management.entity.Member;
import com.fitness.management.repository.MemberRepository;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/members")
public class MemberController {

    @Autowired
    private MemberRepository memberRepository;

    // GET all members
    @GetMapping
    public List<Member> getAllMembers() {
        return memberRepository.findAll();
    }

    // GET member by ID
    @GetMapping("/{id}")
    public Member getMemberById(@PathVariable Long id) {
        return memberRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("❌ Member not found with ID: " + id));
    }

    // CREATE member
    @PostMapping
    public Member addMember(@RequestBody Member member) {
        return memberRepository.save(member);
    }

    // UPDATE member
    @PutMapping("/{id}")
    public Member updateMember(@PathVariable Long id, @RequestBody Member updatedMember) {

        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("❌ Member not found with ID: " + id));

        if (updatedMember.getName() != null) member.setName(updatedMember.getName());
        if (updatedMember.getEmail() != null) member.setEmail(updatedMember.getEmail());
        if (updatedMember.getPhone() != null) member.setPhone(updatedMember.getPhone());
        if (updatedMember.getMembershipType() != null) member.setMembershipType(updatedMember.getMembershipType());

        return memberRepository.save(member);
    }

    // DELETE member — ADMIN ONLY
    @DeleteMapping("/{id}")
    public String deleteMember(
            @PathVariable Long id,
            @RequestHeader("role") String role
    ) {
        if(!role.equals("ADMIN")) {
            return "⛔ ACCESS DENIED — ONLY ADMIN CAN DELETE MEMBERS";
        }

        if (!memberRepository.existsById(id)) {
            return "❌ Member not found";
        }

        memberRepository.deleteById(id);
        return "✔ Member deleted with ID: " + id;
    }
}
