package com.fitness.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.fitness.management.entity.Trainer;
import com.fitness.management.repository.TrainerRepository;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/trainers")
public class TrainerController {

    @Autowired
    private TrainerRepository trainerRepository;

    // CREATE - Add trainer
    @PostMapping
    public Trainer addTrainer(@RequestBody Trainer trainer) {
        return trainerRepository.save(trainer);
    }

    // READ - Get all trainers
    @GetMapping
    public List<Trainer> getAllTrainers() {
        return trainerRepository.findAll();
    }

    // READ - Get trainer by ID
    @GetMapping("/{id}")
    public Trainer getTrainerById(@PathVariable Long id) {
        return trainerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trainer not found with id: " + id));
    }

    // UPDATE trainer
    @PutMapping("/{id}")
    public Trainer updateTrainer(@PathVariable Long id, @RequestBody Trainer trainerDetails) {
        Trainer trainer = trainerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trainer not found with id: " + id));

        trainer.setName(trainerDetails.getName());
        trainer.setEmail(trainerDetails.getEmail());
        trainer.setPhone(trainerDetails.getPhone());
        trainer.setSpecialization(trainerDetails.getSpecialization());
        trainer.setExperienceYears(trainerDetails.getExperienceYears());

        return trainerRepository.save(trainer);
    }

    // DELETE trainer
    @DeleteMapping("/{id}")
    public String deleteTrainer(@PathVariable Long id) {
        trainerRepository.deleteById(id);
        return "Trainer deleted with id: " + id;
    }
}
