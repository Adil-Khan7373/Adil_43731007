package com.fitness.management.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sessions")
public class Session {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long memberId;

    @Column(nullable = false)
    private Long trainerId;

    @Column(nullable = false)
    private String sessionType;

    private LocalDateTime sessionTime;

    @Column(nullable = false)
    private String status = "BOOKED";

    public Session() {
        // default timestamp set when session is created
        this.sessionTime = LocalDateTime.now();
    }

    // GETTERS
    public Long getId() {
        return id;
    }

    public Long getMemberId() {
        return memberId;
    }

    public Long getTrainerId() {
        return trainerId;
    }

    public String getSessionType() {
        return sessionType;
    }

    public LocalDateTime getSessionTime() {
        return sessionTime;
    }

    public String getStatus() {
        return status;
    }

    // SETTERS
    public void setId(Long id) {
        this.id = id;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public void setTrainerId(Long trainerId) {
        this.trainerId = trainerId;
    }

    public void setSessionType(String sessionType) {
        this.sessionType = sessionType;
    }

    public void setSessionTime(LocalDateTime sessionTime) {
        this.sessionTime = sessionTime;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
