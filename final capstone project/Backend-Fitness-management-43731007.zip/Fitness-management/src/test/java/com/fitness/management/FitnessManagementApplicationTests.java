package com.fitness.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitnessManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
